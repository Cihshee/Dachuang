/**
 * Created by 30947 on 2018/7/18.
 */
$(function() {

    char1();
    char2();

})

//统计分析图
function char1() {

    var myChart = echarts.init($("#char1")[0]);

    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function(params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [{
            type: 'category',
            splitLine: { show: false },
            data: ['时间', '地点', '金额', '结论'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }

        }],
        yAxis: [{
            type: 'value',
            splitLine: { show: false },
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }
        }],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: [350, 30, 40, 20]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })
    myChart.on('click', function(param) {
        setTimeout(function() {
            location.href = "https://gitee.com/iGaoWei/big-data-view";
        }, 20000);
    });
}

function char2() {

    var myChart = echarts.init($("#char2")[0]);

    option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        grid: { show: 'true', borderWidth: '0' },
        legend: {
            data: ['麻将', '买大小', '博彩', '炸金花', '其他'],
            textStyle: {
                color: '#ffffff',

            }
        },

        calculable: false,
        xAxis: [{
            type: 'value',
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            },
            splitLine: {
                lineStyle: {
                    color: ['#f2f2f2'],
                    width: 0,
                    type: 'solid'
                }
            }

        }],
        yAxis: [{
            type: 'category',
            data: ['第四季度', '第三季度', '第二季度', '第一季度'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            },
            splitLine: {
                lineStyle: {
                    width: 0,
                    type: 'solid'
                }
            }
        }],
        series: [{
                name: '麻将',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [32, 30, 30, 33]
            },
            {
                name: '买大小',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [12, 13, 10, 13]
            },
            {
                name: '博彩',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [22, 18, 19, 23]
            },
            {
                name: '炸金花',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [15, 21, 20, 15]
            },
            {
                name: '其他',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [15, 22, 11, 14]
            }

        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })
    myChart.on('click', function(param) {
        alert("更多模板，关注公众号【折腾不止的追梦人】\n回复'BigDataView'即可获取\n或前往Gitee下载 https://gitee.com/iGaoWei/big-data-view")
        setTimeout(function() {
            location.href = "https://gitee.com/iGaoWei/big-data-view";
        }, 20000);
    });


}
// function char3() {

//     var myChart = echarts.init($("#char3")[0]);

//     option = {
//         tooltip: {
//             trigger: 'item',
//             formatter: "{a} <br/>{b} : {c} ({d}%)"
//         },
//         legend: {
//             orient: 'vertical',
//             x: 'right',
//             textStyle: {
//                 color: '#ffffff',

//             },
//             data: ['QQ号', '住址', '微信号', '户籍', '支付宝号', '电话号码']
//         },

//         calculable: false,
//         series: [
//             {
//                 name: '类型',
//                 type: 'pie',
//                 radius: ['40%', '70%'],
//                 itemStyle: {
//                     normal: {
//                         label: {
//                             show: false
//                         },
//                         labelLine: {
//                             show: false
//                         }
//                     },
//                     emphasis: {
//                         label: {
//                             show: true,
//                             position: 'center',
//                             textStyle: {
//                                 fontSize: '20',
//                                 fontWeight: 'bold'
//                             }
//                         }
//                     }
//                 },
//                 data: [
//                     { value: 35, name: 'QQ号' },
//                     { value: 35, name: '住址' },
//                     { value: 37, name: '微信号' },
//                     { value: 28, name: '户籍' },
//                     { value: 19, name: '支付宝号' },
//                     { value: 26, name: '电话号码' }
//                 ]
//             }
//         ]
//     };

//     myChart.setOption(option);
//     window.addEventListener('resize', function () { myChart.resize(); })

// }
// function char4() {

//     var myChart = echarts.init($("#char4")[0]);

//     option = {
//         grid: { show: 'true', borderWidth: '0' },
//         tooltip: {
//             trigger: 'axis',
//             axisPointer: {            // 坐标轴指示器，坐标轴触发有效
//                 type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
//             },

//             formatter: function (params) {
//                 var tar = params[0];
//                 return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
//             }
//         },

//         xAxis: [
//             {
//                 type: 'category',
//                 splitLine: { show: false },
//                 data: ['时间', '地点', '金额', '结论'],
//                 axisLabel: {
//                     show: true,
//                     textStyle: {
//                         color: '#fff'
//                     }
//                 }

//             }
//         ],
//         yAxis: [
//             {
//                 type: 'value',
//                 splitLine: { show: false },
//                 axisLabel: {
//                     show: true,
//                     textStyle: {
//                         color: '#fff'
//                     }
//                 }
//             }
//         ],
//         series: [

//             {
//                 name: '报警数量',
//                 type: 'bar',
//                 stack: '总量',
//                 itemStyle: { normal: { label: { show: true, position: 'inside' } } },
//                 data: [35, 30, 40, 20]
//             }
//         ]
//     };

//     myChart.setOption(option);
//     window.addEventListener('resize', function () { myChart.resize(); })
//     myChart.on('click', function (param) {
//         setTimeout(function () {
//             location.href = "https://gitee.com/iGaoWei/big-data-view";
//         }, 20000);
//     });
// }
var area = document.getElementById('moocBox');
var iliHeight = 80; //单行滚动的高度
var speed = 50; //滚动的速度
area.scrollTop = 0;
area.innerHTML += area.innerHTML; //克隆一份一样的内容
var timer = null;

function startMove() {
    area.scrollTop++;
    if (area.scrollTop % iliHeight == 0) {
        clearInterval(timer);
        setTimeout("startMove()", 1000);
    } else {
        if (area.scrollTop >= area.scrollHeight / 2) {
            area.scrollTop = 0;
        }
        setTimeout("startMove()", 50);
    }
}
startMove();