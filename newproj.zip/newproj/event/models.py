from django.db import models

# Create your models here.

class MainEvent(models.Model):
    index = models.IntegerField(default=0)
    element = models.CharField(max_length=100, default='')
    number = models.IntegerField(default=0)
    conclusionNum = models.IntegerField(default=0)

class SubEvent(models.Model):
    index = models.IntegerField(default=0)
    element = models.CharField(max_length=100, default='')
    number = models.IntegerField(default=0)

class PersonData(models.Model):
    name = models.CharField(max_length=100,default='')
    sex = models.CharField(max_length=100, default='')
    phone = models.CharField(max_length=100, default='')
    identy = models.CharField(max_length=100, default='')
    other = models.CharField(max_length=100, default='')

class TotalNum(models.Model):
    index = models.IntegerField(default=0)
    name = models.CharField(max_length=20,default='')
    number = models.IntegerField(default=0)