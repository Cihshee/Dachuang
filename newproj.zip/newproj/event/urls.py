from django.urls import path

from . import views

urlpatterns = [
    path('addEvent/', views.addMainEvent),
    path('getEventData/', views.getEventData),
    path('getSubEventData/', views.getSubEventData),
    path('addPerson/', views.addPersonData),
]