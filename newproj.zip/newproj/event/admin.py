from django.contrib import admin

# Register your models here.
from .models import MainEvent, SubEvent, PersonData, TotalNum

admin.site.register(MainEvent) 
admin.site.register(SubEvent) 
admin.site.register(PersonData) 
admin.site.register(TotalNum) 