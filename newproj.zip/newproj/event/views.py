from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .models import MainEvent, SubEvent, PersonData
import json
# Create your views here.

def addMainEvent(request):

    return HttpResponse('success')

def getEventData(request):
    data = list()
    mainEventData = MainEvent.objects.values()
    for e in mainEventData:
        data.append(e)
    return JsonResponse({'data':data})

def getSubEventData(request):
    data = list()
    subEventData = SubEvent.objects.values()
    for e in subEventData:
        data.append(e)
    return JsonResponse({'data':data})

def addPersonData(request):
    personData = json.load(request)
    PersonData.objects.create(name = personData['name'],
                                sex = personData['sex'],
                                phone = personData['phone'],
                                identy = personData['identy'],
                                other = personData['other'])
    
    if len(personData['phone'])!=0:
        SubEvent = MainEvent.objects.get(index = 4)
        SubEvent.number +=1
        SubEvent.save()

    return HttpResponse("success")