/**
 /*大屏
 */
$(function () {

    char1();
    char2();
    char3();
    char4();
    char5();
})

//统计分析图
function char1() {

    var myChart = echarts.init($("#char1")[0]);

    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function (params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [
            {
                type: 'category',
                splitLine: { show: false },
                data: ['时间', '地点', '金额', '结论'],
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }

            }
        ],
        yAxis: [
            {
                type: 'value',
                splitLine: { show: false },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }
            }
        ],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: [35, 30, 40, 20]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function () { myChart.resize(); })
}
function char2() {

    var myChart = echarts.init($("#char2")[0]);

    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            x: 'right',
            textStyle: {
                color: '#ffffff',

            },
            data: ['QQ号', '住址', '微信号', '户籍', '支付宝号', '电话号码']
        },

        calculable: false,
        series: [
            {
                name: '类型',
                type: 'pie',
                radius: ['40%', '70%'],
                itemStyle: {
                    normal: {
                        label: {
                            show: false
                        },
                        labelLine: {
                            show: false
                        }
                    },
                    emphasis: {
                        label: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '20',
                                fontWeight: 'bold'
                            }
                        }
                    }
                },
                data: [
                    { value: 35, name: 'QQ号' },
                    { value: 35, name: '住址' },
                    { value: 37, name: '微信号' },
                    { value: 28, name: '户籍' },
                    { value: 19, name: '支付宝号' },
                    { value: 26, name: '电话号码' }
                ]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function () { myChart.resize(); })

}
function char3() {

    var myChart = echarts.init($("#char3")[0]);

    option = {
        angleAxis: {
            type: 'category',
            data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        radiusAxis: {},
        polar: {},
        series: [
            {
                type: 'bar',
                data: [3, 2, 3, 4, 4, 5, 6],
                coordinateSystem: 'polar',
                name: '抢劫',
                stack: 'a',
                emphasis: {
                    focus: 'series'
                }
            },
            {
                type: 'bar',
                data: [3, 4, 2, 1, 4, 5, 5],
                coordinateSystem: 'polar',
                name: '赌博',
                stack: 'a',
                emphasis: {
                    focus: 'series'
                }
            },
            {
                type: 'bar',
                data: [3, 2, 3, 4, 3, 4, 5],
                coordinateSystem: 'polar',
                name: '诈骗',
                stack: 'a',
                emphasis: {
                    focus: 'series'
                }
            },
            {
                type: 'bar',
                data: [5, 3, 4, 4, 6, 6, 7],
                coordinateSystem: 'polar',
                name: '偷盗',
                stack: 'a',
                emphasis: {
                    focus: 'series'
                }
            }
        ],
        legend: {
            orient: 'vertical',
            x: 'left',
            show: true,
            data: ['抢劫', '赌博', '诈骗', '偷盗'],
            textStyle: {
                color: '#ffffff',

            }
        }
    };

    myChart.setOption(option);
    window.addEventListener('resize', function () { myChart.resize(); })

}
function char4() {

    var myChart = echarts.init($("#char4")[0]);

    option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: 'black'
                }
            }
        },
        legend: {
            data: ['抢劫', '赌博', '诈骗', '偷盗'],
            textStyle: {
                color: '#ffffff',

            }
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: ['六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }
            }
        ],
        yAxis: [
            {
                type: 'value',
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }
            }
        ],
        series: [
            {
                name: '抢劫',
                type: 'line',
                stack: 'Total',
                areaStyle: {},
                emphasis: {
                    focus: 'series'
                },
                data: [13, 15, 17, 20, 13, 19, 13]
            },
            {
                name: '赌博',
                type: 'line',
                stack: 'Total',
                areaStyle: {},
                emphasis: {
                    focus: 'series'
                },
                data: [33, 28, 30, 32, 33, 35, 42]
            },
            {
                name: '诈骗',
                type: 'line',
                stack: 'Total',
                areaStyle: {},
                emphasis: {
                    focus: 'series'
                },
                data: [21, 15, 18, 15, 18, 16, 13]
            },
            {
                name: '偷盗',
                type: 'line',
                stack: 'Total',
                areaStyle: {},
                emphasis: {
                    focus: 'series'
                },
                data: [33, 42, 35, 33, 36, 30, 32]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function () { myChart.resize(); })
}
function char5() {

    var myChart = echarts.init($("#char5")[0]);

    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function (params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [
            {
                type: 'category',
                splitLine: { show: false },
                data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }

            }
        ],
        yAxis: [
            {
                type: 'value',
                splitLine: { show: false },
                axisLabel: {
                    show: true,
                    textStyle: {
                        color: '#fff'
                    }
                }
            }
        ],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: [321, 133, 300, 200, 543, 300, 214, 234, 243, 324, 242, 234]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function () { myChart.resize(); })

}