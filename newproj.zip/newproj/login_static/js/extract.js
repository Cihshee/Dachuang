window.onload = function() {
    var btn = document.querySelector("#btn");
    btn.onclick = function() {
        var textValue = document.querySelector("#text").value;
        var eventTypeValue = document.querySelector("#eventType").value;
        $.ajax({
            type: "post",
            url: "http://127.0.0.1:5000/process/single",
            xhrFields: {
                withCredentials: true
            },
            processData: false,
            data: JSON.stringify({ "text": textValue, "eventType": eventTypeValue }),
            contentType: "application/json",
            dataType: "json",
            success: function(result) {
                alert("抽取成功");
                console.log(result);
                var time_result = document.querySelector("#time_result");
                var place_result = document.querySelector("#place_result");
                var detail_result = document.querySelector("#detail_result");
                var name1_result = document.querySelector("#name1_result");
                var IDnum1_result = document.querySelector("#IDnum1_result");
                var phonenum1_result = document.querySelector("#phonenum1_result");
                var name2_result = document.querySelector("#name2_result");
                var IDnum2_result = document.querySelector("#IDnum2_result");
                var phonenum2_result = document.querySelector("#phonenum2_result");
                if (result.报案时间)
                    time_result.value = result.报案时间.content;
                if (result.案发时间)
                    time_result.value = result.案发时间.content;
                if (result.案发地址)
                    place_result.value = result.案发地址.content;
                if (result.涉案总金额)
                    detail_result.value += "涉案总金额:" + result.涉案总金额.content + "\n";
                if (result.处警结论)
                    detail_result.value += "处警结论:" + result.处警结论.content + "\n";
                if (result.触发词)
                    detail_result.value += "触发词:" + result.触发词.content + "\n";
                if (result.涉案人员[0]) {
                    if (result.涉案人员[0].姓名)
                        name1_result.value = result.涉案人员[0].姓名.content;
                    if (result.涉案人员[0].身份证号)
                        IDnum1_result.value = result.涉案人员[0].身份证号.content;
                    else
                        IDnum1_result.value = "无";
                    if (result.涉案人员[0].电话号码)
                        phonenum1_result.value = result.涉案人员[0].电话号码.content;
                    else
                        phonenum1_result.value = "无";
                }
                if (result.涉案人员[1]) {
                    if (result.涉案人员[1].姓名)
                        name2_result.value = result.涉案人员[1].姓名.content;
                    if (result.涉案人员[1].身份证号)
                        IDnum2_result.value = result.涉案人员[1].身份证号.content;
                    else
                        IDnum2_result.value = "无";
                    if (result.涉案人员[1].电话号码)
                        phonenum2_result.value = result.涉案人员[1].电话号码.content;
                    else
                        phonenum2_result.value = "无";
                }
                if (result.code == "200")
                    console.log("抽取成功！");
                else console.log(result.message);
            },
        });
    };
};