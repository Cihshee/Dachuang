/**
 /*大屏
 */
$(function() {

    char1();
    char2();
    char3();
    char4();
    char5();
})

//统计分析图
async function char1() {

    var myChart = echarts.init($("#char1")[0]);
    let charData = new Array()
    let mainEventData = new Array()
    console.log("getcharData")
    await axios.get('http://127.0.0.1:8000/event/getEventData/')
        .then(res => {
            resData = res.data.data
            mainEventData = res.data.data
            console.log(resData)
            for (e in resData) {
                charData.push(resData[e]['number'])
            }
        })
        .catch(err => {
            console.log('错误' + err)
        })
    console.log(charData)

    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function(params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [{
            type: 'category',
            splitLine: { show: false },
            data: ['时间', '地点', '金额', '结论'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }

        }],
        yAxis: [{
            type: 'value',
            splitLine: { show: false },
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }
        }],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: charData
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })
    myChart.on('click', function(param) {
        setTimeout(function() {
            location.href = "https://gitee.com/iGaoWei/big-data-view";
        }, 20000);
    });

    var str = "";
    for (var ind = 0; ind < mainEventData.length; ind++) {
        str += "<tr>"
        str += "<td>" + mainEventData[ind]['index'] + "</td>"
        str += "<td>" + mainEventData[ind]['element'] + "</td>"
        str += "<td>" + mainEventData[ind]['number'] + "</td>"
        str += "<tr>"
    }
    document.getElementById("main_event_table").innerHTML = str;
}

async function char2() {

    var myChart = echarts.init($("#char2")[0]);
    let charData = new Array()
    let subEventData = new Array()
    console.log("subEventData")
    await axios.get('http://127.0.0.1:8000/event/getSubEventData/')
        .then(res => {
            resData = res.data.data
            subEventData = res.data.data
            console.log(resData)
            for (e in resData) {
                charData.push({ value: resData[e]['number'], name: resData[e]['element'] })
            }
        })
        .catch(err => {
            console.log('错误' + err)
        })
    console.log(charData)
    option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            x: 'right',
            textStyle: {
                color: '#ffffff',

            },
            data: ['QQ号', '住址', '微信号', '户籍', '支付宝号', '电话号码']
        },

        calculable: false,
        series: [{
            name: '类型',
            type: 'pie',
            radius: ['40%', '70%'],
            itemStyle: {
                normal: {
                    label: {
                        show: false
                    },
                    labelLine: {
                        show: false
                    }
                },
                emphasis: {
                    label: {
                        show: true,
                        position: 'center',
                        textStyle: {
                            fontSize: '20',
                            fontWeight: 'bold'
                        }
                    }
                }
            },
            data: charData
        }]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })

    var str = "";
    for (var ind = 0; ind < subEventData.length; ind++) {
        str += "<tr>"
        str += "<td>" + subEventData[ind]['index'] + "</td>"
        str += "<td>" + subEventData[ind]['element'] + "</td>"
        str += "<td>" + subEventData[ind]['number'] + "</td>"
        str += "<tr>"
    }
    document.getElementById("sub_event_charData").innerHTML = str;
}

function char3() {

    var myChart = echarts.init($("#char3")[0]);

    option = {
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        grid: { show: 'true', borderWidth: '0' },
        legend: {
            data: ['麻将', '买大小', '博彩', '炸金花', '其他'],
            textStyle: {
                color: '#ffffff',

            }
        },

        calculable: false,
        xAxis: [{
            type: 'value',
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            },
            splitLine: {
                lineStyle: {
                    color: ['#f2f2f2'],
                    width: 0,
                    type: 'solid'
                }
            }

        }],
        yAxis: [{
            type: 'category',
            data: ['第四季度', '第三季度', '第二季度', '第一季度'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            },
            splitLine: {
                lineStyle: {
                    width: 0,
                    type: 'solid'
                }
            }
        }],
        series: [{
                name: '麻将',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [32, 30, 30, 33]
            },
            {
                name: '买大小',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [12, 13, 10, 13]
            },
            {
                name: '博彩',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [22, 18, 19, 23]
            },
            {
                name: '炸金花',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [15, 21, 20, 15]
            },
            {
                name: '其他',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'insideRight' } } },
                data: [15, 22, 11, 14]
            }

        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })
    myChart.on('click', function(param) {
        alert("更多模板，关注公众号【折腾不止的追梦人】\n回复'BigDataView'即可获取\n或前往Gitee下载 https://gitee.com/iGaoWei/big-data-view")
        setTimeout(function() {
            location.href = "https://gitee.com/iGaoWei/big-data-view";
        }, 20000);
    });


}

async function char4() {
    console.log("Char4")
    var myChart = echarts.init($("#char4")[0]);
    let charData = new Array()
    let mainEventData = new Array()
    console.log("getcharData")
    await axios.get('http://127.0.0.1:8000/event/getEventData/')
        .then(res => {
            resData = res.data.data
            mainEventData = res.data.data
            console.log(resData)
            for (e in resData) {
                charData.push(resData[e]['number'])
            }
        })
        .catch(err => {
            console.log('错误' + err)
        })
    console.log(charData)
    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function(params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [{
            type: 'category',
            splitLine: { show: false },
            data: ['时间', '地点', '金额', '结论'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }

        }],
        yAxis: [{
            type: 'value',
            splitLine: { show: false },
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }
        }],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: charData
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })
    myChart.on('click', function(param) {
        setTimeout(function() {
            location.href = "https://gitee.com/iGaoWei/big-data-view";
        }, 20000);
    });

    var str = "";
    for (var ind = 0; ind < mainEventData.length; ind++) {
        str += "<tr>"
        str += "<td>" + mainEventData[ind]['index'] + "</td>"
        str += "<td>" + mainEventData[ind]['element'] + "</td>"
        str += "<td>" + mainEventData[ind]['number'] + "</td>"
        str += "<tr>"
    }
    document.getElementById("alert_table").innerHTML = str;
}

function char5() {

    var myChart = echarts.init($("#char5")[0]);

    option = {
        grid: { show: 'true', borderWidth: '0' },
        tooltip: {
            trigger: 'axis',
            axisPointer: { // 坐标轴指示器，坐标轴触发有效
                type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            },

            formatter: function(params) {
                var tar = params[0];
                return tar.name + '<br/>' + tar.seriesName + ' : ' + tar.value;
            }
        },

        xAxis: [{
            type: 'category',
            splitLine: { show: false },
            data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }

        }],
        yAxis: [{
            type: 'value',
            splitLine: { show: false },
            axisLabel: {
                show: true,
                textStyle: {
                    color: '#fff'
                }
            }
        }],
        series: [

            {
                name: '报警数量',
                type: 'bar',
                stack: '总量',
                itemStyle: { normal: { label: { show: true, position: 'inside' } } },
                data: [321, 133, 300, 200, 543, 300, 214, 234, 243, 324, 242, 234]
            }
        ]
    };

    myChart.setOption(option);
    window.addEventListener('resize', function() { myChart.resize(); })

}