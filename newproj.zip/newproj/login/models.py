from django.db import models


# Create your models here.

class UserInfo(models.Model):
    user = models.CharField(max_length=32)
    pwd = models.CharField(max_length=32)

# class Article(models.Model):
#     title = models.CharField(max_length=32, default='Title')
#     content = models.TextField(null=True)
