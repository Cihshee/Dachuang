import hashlib
from re import T
from unicodedata import name

from django.http import HttpResponse
from django.shortcuts import HttpResponseRedirect
from django.shortcuts import render
from .models import *
from event.models import TotalNum
import json
# Create your views here.

# 首页界面
def index(request):
    temp = TotalNum.objects.get(name="案件总数")
    totalEvent = temp.number

    temp = TotalNum.objects.get(name="已完成任务数")
    finishNum = temp.number

    temp = TotalNum.objects.get(name="未完成任务数")
    notFinishNum = temp.number

    temp = TotalNum.objects.get(name="今日报警")
    todayAlert = temp.number

    totalData = {
                "totalEvent":totalEvent, 
                "finishNum":finishNum, 
                "notFinishNum":notFinishNum, 
                "todayAlert":todayAlert
            }
    return render(request, 'index.html', {"totalData":totalData})


# 注册页面
# 渲染注册页面
def register(request):
    return render(request, 'register.html')


# 判断是否注册成功
def register_judge(request):
    data = request.POST
    username = data.get("username", '')
    password = data.get("password", '')
    sure_password = data.get("sure_password")
    # invite_code = data.get("invite_code")

    if username and password and sure_password:
        # and invite_code:
        if password != sure_password:
            return render(request, 'register.html', {"msg": "两次输入的密码不同，请重新输入！"})
        # elif invite_code != '123':
        #     return HttpResponse("验证码错误！")
        else:
            userinfo = UserInfo(user=username, pwd=password)
            userinfo.save()
            return render(request, 'log.html', {"msg": "注册成功！"})
    else:
        return render(request, 'register.html', {"msg": "请将注册信息输入完整！"})


# 登录页面
# 渲染登录页面
def login(request):
    return render(request, 'log.html')


# 判断是否登录成功
def login_judge(request):
    data = request.POST
    username = data.get("username", '')
    password = data.get("password", '')
    print(username)

    if username and password:
        flag = UserInfo.objects.filter(user=username, pwd=password).count()
        if flag >= 1:
            temp = TotalNum.objects.get(name="案件总数")
            totalEvent = temp.number
            print(totalEvent)

            temp = TotalNum.objects.get(name="已完成任务数")
            finishNum = temp.number

            temp = TotalNum.objects.get(name="未完成任务数")
            notFinishNum = temp.number

            temp = TotalNum.objects.get(name="今日报警")
            todayAlert = temp.number

            totalData = {
                "totalEvent":totalEvent, 
                "finishNum":finishNum, 
                "notFinishNum":notFinishNum, 
                "todayAlert":todayAlert
            }
            return render(request, 'index.html', {"totalData":totalData})
        else:
            return render(request, 'log.html', {"msg": "账号密码错误！"})
    else:
        # return HttpResponse("请将登录信息输入完整！")
        return render(request, 'log.html', {"msg": "请将登录信息输入完整！"})


# 查询界面
def search(request):
    return render(request, 'map.html')


# 添加界面
def message(request):
    return render(request, 'message.html')


# 可视化界面
def static(request):
    temp = TotalNum.objects.get(name="案件总数")
    totalEvent = temp.number

    temp = TotalNum.objects.get(name="已完成任务数")
    finishNum = temp.number

    temp = TotalNum.objects.get(name="未完成任务数")
    notFinishNum = temp.number

    temp = TotalNum.objects.get(name="今日报警")
    todayAlert = temp.number

    totalData = {
                "totalEvent":totalEvent, 
                "finishNum":finishNum, 
                "notFinishNum":notFinishNum, 
                "todayAlert":todayAlert
            }
    return render(request, 'static.html', {"totalData":totalData})


# 预警界面
def predict(request):
    return render(request, 'predict.html')


# 界面
def table1(request):
    return render(request, 'table1.html')


# 界面
def table2(request):
    return render(request, 'table2.html')


# 界面
def tail_more(request):
    return render(request, 'tail_more.html')


# 界面
def tail_sm(request):
    return render(request, 'tail_sm.html')


# 密码加密保存到数据库
# def setPassword(password):
#     """
#     加密密码，算法单次md5
#     :param apssword: 传入的密码
#     :return: 加密后的密码
#     """
#     md5 = hashlib.md5()
#     md5.update(password.encode())
#     password = md5.hexdigest()
#     return str(password)

# user_list = []



# 登录页面
# def login(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
#         # print(username, password)
#         # temp = {'user': username, 'pwd': password}
#         # user_list.append(temp)
#
#         # 数据保存到数据库
#         models.UserInfo.objects.create(
#             user=username,
#             pwd=password
#         )
#
#     # 数据库读取数据
#     user_list = models.UserInfo.objects.all()
#     print(user_list)
#
#     # return HttpResponse('登录成功')
#     return render(request, 'log.html', {'data': user_list})


# 注册页面
# def register(request):
#     if request.method == "POST" and request.POST:
#         data = request.POST
#         username = data.get("username")
#         # email = data.get("email")
#         password = data.get("password")
#         models.UserInfo.objects.create(
#             user=username,
#             # email=email,
#             pwd=setPassword(password),
#         )
#         return HttpResponse("登录成功!")
#     return render(request, 'register.html', {'data': user_list})
