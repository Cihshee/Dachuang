from django.urls import path

from . import views

urlpatterns = [
    path('', views.login, name='login'),
    path('index/', views.login_judge, name='login_judge'),
    path('register.html', views.register, name='register'),
    path('login/', views.register_judge, name='register_judge'),

    path('index/register.html', views.register, name='register'),
    path('index/index.html', views.index, name='index'),
    path('index/message.html', views.message, name='message'),
    path('index/map.html', views.search, name='map'),
    path('index/static.html', views.static, name='static'),
    path('index/predict.html', views.predict, name='predict'),
    path('index/table1.html', views.table1, name='table1'),
    path('index/table2.html', views.table2, name='table2'),
    path('index/tail_more.html', views.tail_more, name='tail_more'),
    path('index/tail_sm.html', views.tail_sm, name='tail_sm'),

    # path('index/', views.index, name='index'),
]