import imp
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
import json
from .models import AlertMessage, PersonMessage, PeopleMessage
from event.models import MainEvent, SubEvent, TotalNum
# Create your views here.
def addAlertData(request):
    print('addAlertData')
    print(request.POST)
    alertData = json.load(request)
    print(alertData)
    AlertMessage.objects.create(name = alertData['name'], 
                                time =alertData['time'],
                                location = alertData['location'],
                                type = alertData['type'],
                                state = alertData['state'],
                                detail = alertData['detail'],
                                info = alertData['info'])

    if len(alertData['time'])!=0:
        mainEvent = MainEvent.objects.get(index = 3)
        mainEvent.number +=1
        mainEvent.save()

    if len(alertData['location'])!=0:
        mainEvent = MainEvent.objects.get(index = 4)
        mainEvent.number +=1
        mainEvent.save()

    if len(alertData['info'])!=0:
        mainEvent = MainEvent.objects.get(index = 2)
        mainEvent.number +=1
        mainEvent.save()

    if len(alertData['state'])!=0:
        if alertData['state'] == '已处理':
            temp = TotalNum.objects.get(name='已完成任务数')
            temp.number+=1
            temp.save()
        if alertData['state'] == '未处理':
            temp = TotalNum.objects.get(name='未完成任务数')
            temp.number+=1
            temp.save()
        
    mainEvent = MainEvent.objects.get(index = 1)
    mainEvent.number +=1
    mainEvent.save()

    temp = TotalNum.objects.get(name='案件总数')
    temp.number+=1
    temp.save()

    temp = TotalNum.objects.get(name='今日报警')
    temp.number+=1
    temp.save()
    
    return HttpResponse("success")

def addPersonData(request):
    personData = json.load(request)
    PeopleMessage.objects.create(name = personData['name'],
                                sex = personData['sex'],
                                phone = personData['phone'],
                                identy = personData['identy'],
                                other = personData['other'])
    
    if len(personData['phone'])!=0:
        SubEvent = MainEvent.objects.get(index = 4)
        SubEvent.number +=1
        SubEvent.save()

    return HttpResponse("success")
