from django.contrib import admin

# Register your models here.

from .models import AlertMessage, PersonMessage, PeopleMessage

admin.site.register(AlertMessage) 
admin.site.register(PersonMessage) 
admin.site.register(PeopleMessage) 