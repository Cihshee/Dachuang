from django.db import models

# Create your models here.
class AlertMessage(models.Model):
    name = models.CharField(max_length=100,default='')
    time = models.CharField(max_length=100, default='')
    location = models.CharField(max_length=100, default='')
    type = models.CharField(max_length=100, default='')
    state = models.CharField(max_length=100, default='')
    detail = models.CharField(max_length=300, default='')
    info = models.CharField(max_length=100, default='')

class PersonMessage(models.Model):
    name = models.CharField(max_length=100,default='')
    sex = models.CharField(max_length=100, default='')
    phone = models.CharField(max_length=100, default='')
    identy = models.CharField(max_length=100, default='')
    other = models.CharField(max_length=100, default='')


class PeopleMessage(models.Model):
    name = models.CharField(max_length=100,default='')
    sex = models.CharField(max_length=100, default='')
    phone = models.CharField(max_length=100, default='')
    identy = models.CharField(max_length=100, default='')
    other = models.CharField(max_length=100, default='')